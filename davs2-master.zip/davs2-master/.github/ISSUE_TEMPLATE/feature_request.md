---
name: Feature request
about: Suggest an idea for this project / 功能请求

---

请详细填写以下四项关键元素

## 功能描述

## 功能带来的效应

## 缺少此功能的影响

## 实现的思路与方式
